# NorthWest Studios — Website

A single-page, no-build website. No frameworks, no dependencies to install — just `index.html` plus a small `images/` folder for the logo and icons. It's fast because there's almost nothing to load.

## Files in this folder

- `index.html` — the entire site.
- `images/` — your logo (`logo.png`) and the favicon/app-icon files generated from it.
- `robots.txt`, `sitemap.xml` — tell search engines the site exists and that they're welcome to crawl it.
- `llms.txt` — a short plain-text summary of the business for AI assistants and answer engines (like ChatGPT or Perplexity) that increasingly read sites directly. This is an emerging convention, not a guarantee any particular AI reads it, but it costs nothing and gives them a clean, accurate summary to work from instead of guessing.

Upload all of it — keep `images/` as a subfolder, not flattened into the root, since `index.html` points to `images/logo.png`.

## Host it on GitHub Pages (free)

1. Create a new repository on GitHub (e.g. `northwest-studios`).
2. Upload everything in this folder to the root of that repository, keeping the `images/` folder intact (drag and drop on the GitHub website works fine, or use git).
3. In the repo, go to **Settings → Pages**.
4. Under "Build and deployment," set **Source** to `Deploy from a branch`, branch `main`, folder `/ (root)`. Save.
5. Wait a minute or two — GitHub gives you a URL like `https://yourusername.github.io/northwest-studios/`.
6. Optional: to use your own domain (e.g. `northweststudios.com`), add it under **Settings → Pages → Custom domain**, then create a `CNAME` record with your domain registrar pointing to `yourusername.github.io`. GitHub's docs walk through this step by step.

That's it — no server, no build step, no monthly hosting bill for this part.

## Before you launch, update these

Open `index.html` and replace the placeholders (use Ctrl+F / Cmd+F to find them):

- **Phone number** — currently `(555) 010-0199` / `tel:15550100199`. Appears in the header, hero note isn't affected, CTA band, and contact section. Search for `5550100199` to catch every `tel:` link.
- **Email** — currently `hello@northweststudios.com`.
- **Contact form** — the form currently posts to `https://formspree.io/f/YOUR_FORM_ID`, a placeholder. To make it actually deliver submissions to your inbox:
  1. Go to [formspree.io](https://formspree.io) and create a free account.
  2. Create a new form, and it'll give you a form ID like `abcdwxyz`.
  3. Replace `YOUR_FORM_ID` in the `action="..."` attribute of the `<form>` tag with that ID.
  4. Formspree's free tier covers 50 submissions a month, which is plenty to start.
- **Trades listed** in the strip near the top — edit the list to match who you actually want to target.
- **Domain placeholder** — several files reference `https://www.northweststudios.com/` so search engines and AI crawlers have a canonical URL to point to (this doesn't work as a link until you own that domain and connect it). Once you have your real domain, find-and-replace `northweststudios.com` across `index.html`, `robots.txt`, `sitemap.xml`, and `llms.txt`.

## SEO & GEO (AI answer engines) — what's already built in

- **Structured data (JSON-LD)** in `index.html`'s `<head>` describes the business, price, and service area in a format search engines and AI tools parse directly, and mirrors the on-page FAQ so it can surface as rich results or get quoted directly by AI assistants.
- **`robots.txt` + `sitemap.xml`** so search engines know the page exists and are explicitly invited to index it.
- **`llms.txt`** — a plain-language summary aimed at AI assistants, following an emerging convention some AI crawlers look for.
- **Real `<title>` and meta description**, Open Graph and Twitter card tags so links posted on social media or shared in messages show a proper preview with your logo.
- **A single static HTML page** — no JavaScript framework required to render the content, so every crawler (search engine or AI) sees the same content a person does, with nothing hidden behind client-side rendering.
- **Proper favicon set** (`favicon.ico`, PNG icons, Apple touch icon) generated from your logo, so the site looks finished in browser tabs, bookmarks, and on phone home screens.

None of this guarantees rankings — that depends on backlinks, real content over time, and competition — but it removes every technical reason a search engine or AI crawler would undervalue or misread the page.

## Making small edits later

Everything is in one file, organized top to bottom in the order sections appear on the page (hero, trades, value props, what's included, process, pricing, FAQ, contact, footer). Text lives directly in the HTML — search for the phrase you want to change and edit it in place. Colors and fonts are defined once at the top of the `<style>` block under `:root`, so changing `--rust` or `--forest` there updates the whole site consistently.

## Why it's built this way

- **One HTML file, no build tools** — nothing to install, nothing to break, easy for you or anyone else to edit directly on GitHub.
- **Two font families loaded from Google Fonts** — the only external requests the page makes. Everything else (icons, the estimate-ticket graphic, the logo mark) is plain CSS/SVG, so the page loads fast even on a slow job-site connection.
- **No tracking scripts, no ads, nothing bloating the page** — quicker load times and nothing to explain to a privacy-conscious visitor.
